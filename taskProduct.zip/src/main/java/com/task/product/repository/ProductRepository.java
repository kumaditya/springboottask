package com.task.product.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.task.product.model.Product;

public interface ProductRepository extends JpaRepository<Product,Integer>{

}

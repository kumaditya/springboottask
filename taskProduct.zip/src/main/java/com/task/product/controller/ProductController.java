package com.task.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.task.product.model.Product;
import com.task.product.service.ProductService;

@RestController
public class ProductController {
	
		@Autowired
		ProductService productService;

		@GetMapping("/demo/products")
				public List<Product> getAllProducts() {
			return productService.all();
			
		}
		@GetMapping("/demo/products/{productId}/{productName}")
		public Optional<Product> getProduct( @PathVariable("productId") int id) {
	return productService.productById(id);

	}
		@PostMapping("/demo/products")
		public String addTopic(@RequestBody Product product) {
			productService.addproduct(product);
			return "added product";
		}
			@PutMapping("/demo/product/{productId}")
			public String updateProductById(@RequestBody Product updatedProduct, @PathVariable int productId ) {
				productService.updateProduct(productId,updatedProduct);
				return "updated product with id: " + productId;


	}
			@DeleteMapping("/demo/product/{productId}")
			public String deleteProductById(@PathVariable int productId ) {
				productService.deleteProduct(productId);
				return "deleted product with id: " + productId;
	}

}

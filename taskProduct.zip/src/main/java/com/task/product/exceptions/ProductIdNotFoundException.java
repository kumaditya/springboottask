package com.task.product.exceptions;

public class ProductIdNotFoundException extends RuntimeException {
	public ProductIdNotFoundException(String message) {
		super(message);
	}

}

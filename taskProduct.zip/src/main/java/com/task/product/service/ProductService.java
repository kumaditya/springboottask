package com.task.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.product.exceptions.ProductIdNotFoundException;
import com.task.product.model.Product;
import com.task.product.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	public List<Product> all(){
		List<Product> productsList=new ArrayList<>();	
		productRepository.findAll()
		.forEach(i ->productsList.add(i));
		return productsList;
	}
	
	public Optional<Product> productById(int id){
		Optional<Product> op=productRepository.findById(id);
		if(op.isPresent()) {
			if(op.get().getProductName()!=null)
				return productRepository.findById(id);
			else {
				System.out.println("Product having id " +id +" has no product name defined");
				return productRepository.findById(id);
			}
		}else {
			throw new ProductIdNotFoundException("Product not found for Id:"+id);
		}
		
	}

	public void addproduct(Product topic) {
		productRepository.save(topic);
		
		// TODO Auto-generated method stub
		
	}

	public void updateProduct(int id,Product updatedProduct) {
		// TODO Auto-generated method stub
		productRepository.save(updatedProduct);
 
			}
		
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		productRepository.deleteById(id);
		return "deleted product with id "+ id;
		
	}
	

}
